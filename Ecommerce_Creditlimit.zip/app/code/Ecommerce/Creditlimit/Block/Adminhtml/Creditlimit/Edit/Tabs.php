<?php
namespace Ecommerce\Creditlimit\Block\Adminhtml\Creditlimit\Edit;

/**
 * Admin page left menu
 */
class Tabs extends \Magento\Backend\Block\Widget\Tabs
{
    /**
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('creditlimit_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('Creditlimit Information'));
    }
}